%Init data termisk modell

%Opsett av dataset

%ASEA Q38
%Statorvikling parameter
KIB_S = 349;
TAU_S = 963;
TN_S = 46;
TC_S = 8;

%Transformatorvikling parameter
KIB_T = 349;
TAU_T = 786;
TN_T = 60;
TC_T = 12;





