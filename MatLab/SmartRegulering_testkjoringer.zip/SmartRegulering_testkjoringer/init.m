% Hoved init script


run init_felles.m;
run init_jernbanenett.m;
run init_temperaturbegrenser.m;
run init_termisk_modell.m;