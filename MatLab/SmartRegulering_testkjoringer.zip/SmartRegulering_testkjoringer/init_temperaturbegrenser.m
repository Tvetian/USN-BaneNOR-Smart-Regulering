%Init data temperaturbegrenser


%Regulatorparameter

%Generator
T_ref_g = 60; %[°C]
Kp_g = -547;
Ti_g = 1908; %[s]

%Transformator
T_ref_t = 60; %[°C]
Kp_t = -2000;
Ti_t = 100; %[s]


%Felles
U_upperlimit = 3000; %[V]
U_lowerlimit = 0; %[V]
T_ref_min = min(T_ref_t,T_ref_g); %[°C]


%Omfgivelseskontroller
omgivelsestemperatur_init = 30; %[°C]
T_omgivelser_min = 28; %[°C]
T_omgivelser_max = 30; %[°C]

delta_T_ref = 10; %[°C]
T_ref_o = T_ref_min - delta_T_ref; %[°C] 

Kp_o = 2.324;
Ti_o = 987; %[s]

tau_omgivelser = 500; %[s]
