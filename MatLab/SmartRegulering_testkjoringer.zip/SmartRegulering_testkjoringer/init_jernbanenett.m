%Init data jernbanenett

%Felles parameter
hz = 50/3;


%Generator parameter
Generator1_referanse = 16000; %[V]
Generator2_referanse = 16000; %[V]
Generator3_referanse = 16000; %[V]

Generator1_faseforskyvning = 0.0; %[rad]
Generaotr2_faseforskyvning = 0.0; %[rad]
Generaotr3_faseforskyvning = 0.0; %[rad]

%Sektor parameter

Resistans_Kjoreledning = 0.18; %[ohm/km]
Induktans_Kjoreledning = 1.8143e-3; %[H/km]

Hastighet_last1 = 20; %[km/t]
Startpunkt_last1 = 0.1; %[km]



SektorC_lengde = 40; %[km]
SektorD_lengde = 40; %[km]

SektorC_resistans = Resistans_Kjoreledning*SektorC_lengde; %[ohm*km]
SektorD_resistans = Resistans_Kjoreledning*SektorD_lengde; %[ohm*km]
SektorC_induktans = Induktans_Kjoreledning*SektorC_lengde; %[H*km]
SektorD_induktans = Induktans_Kjoreledning*SektorD_lengde; %[H*km]





%Last parameter

Last1_resistans = 14; %[ohm]
Last1_induktans = 0.1776169; %[H]


Last2_resistans = 30.1*5; %[ohm]
Last2_induktans = 0.1776169; %[H]

%Opsett av dataset
load("motstand_data.mat");


motstand_data = timeseries(datasettmotstand.MotstandOhm, datasettmotstand.Tids);

