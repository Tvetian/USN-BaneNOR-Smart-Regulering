#ifdef __cplusplus
extern "C" {
#endif
#ifndef SMARTREGULERING_TESTER_CB61FC2_49_DS_OBS_EXP_H
#define SMARTREGULERING_TESTER_CB61FC2_49_DS_OBS_EXP_H 1
int32_T SmartRegulering_tester_cb61fc2_49_ds_obs_exp ( const NeDynamicSystem
* sys , const NeDynamicSystemInput * Q , NeDsMethodOutput * M ) ;
#endif
#ifdef __cplusplus
}
#endif
