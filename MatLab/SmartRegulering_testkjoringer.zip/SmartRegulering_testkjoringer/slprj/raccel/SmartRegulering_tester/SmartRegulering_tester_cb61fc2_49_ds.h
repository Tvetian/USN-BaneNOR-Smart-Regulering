#ifdef __cplusplus
extern "C" {
#endif
#ifndef SMARTREGULERING_TESTER_CB61FC2_49_DS_H
#define SMARTREGULERING_TESTER_CB61FC2_49_DS_H 1
extern NeDynamicSystem * SmartRegulering_tester_cb61fc2_49_dae_ds ( PmAllocator
* allocator ) ;
#endif
#ifdef __cplusplus
}
#endif
