#include "ne_ds.h"
#include "SmartRegulering_tester_cb61fc2_49_ds_sys_struct.h"
#include "SmartRegulering_tester_cb61fc2_49_ds_duf.h"
#include "SmartRegulering_tester_cb61fc2_49_ds.h"
#include "SmartRegulering_tester_cb61fc2_49_ds_externals.h"
#include "SmartRegulering_tester_cb61fc2_49_ds_external_struct.h"
#include "ssc_ml_fun.h"
int32_T SmartRegulering_tester_cb61fc2_49_ds_duf ( const NeDynamicSystem *
sys , const NeDynamicSystemInput * t9 , NeDsMethodOutput * out ) { real_T t0
; real_T t2 ; real_T t4 ; out -> mDUF . mX [ 7ULL ] = - 1.0 ; if ( t9 -> mM .
mX [ 1ULL ] != 0 ) { t2 = t9 -> mU . mX [ 0ULL ] * t9 -> mU . mX [ 0ULL ] ;
t0 = - ( - t9 -> mX . mX [ 4ULL ] / ( t2 == 0.0 ? 1.0E-16 : t2 ) ) ; } else {
t0 = 0.0 ; } if ( t9 -> mM . mX [ 0ULL ] != 0 ) { t2 = t9 -> mU . mX [ 2ULL ]
* t9 -> mU . mX [ 2ULL ] ; t4 = - ( - t9 -> mX . mX [ 3ULL ] / ( t2 == 0.0 ?
1.0E-16 : t2 ) ) ; } else { t4 = 0.0 ; } if ( t9 -> mM . mX [ 2ULL ] != 0 ) {
t2 = t9 -> mU . mX [ 5ULL ] * t9 -> mU . mX [ 5ULL ] ; t2 = - ( - t9 -> mX .
mX [ 5ULL ] / ( t2 == 0.0 ? 1.0E-16 : t2 ) ) ; } else { t2 = 0.0 ; } out ->
mDUF . mX [ 0ULL ] = t0 / 1.0E+6 ; out -> mDUF . mX [ 1ULL ] = t9 -> mM . mX
[ 4ULL ] != 0 ? - ( t9 -> mX . mX [ 6ULL ] + t9 -> mX . mX [ 7ULL ] ) : 0.0 ;
out -> mDUF . mX [ 2ULL ] = t4 / 1.0E+6 ; out -> mDUF . mX [ 3ULL ] = t9 ->
mM . mX [ 3ULL ] != 0 ? - t9 -> mX . mX [ 6ULL ] : 0.0 ; out -> mDUF . mX [
4ULL ] = - 1.0E-15 ; out -> mDUF . mX [ 5ULL ] = t2 / 1.0E+6 ; out -> mDUF .
mX [ 6ULL ] = t9 -> mM . mX [ 5ULL ] != 0 ? - t9 -> mX . mX [ 7ULL ] : 0.0 ;
( void ) sys ; ( void ) out ; return 0 ; }
