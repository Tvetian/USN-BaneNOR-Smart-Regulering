#include "ne_ds.h"
#include "SmartRegulering_tester_cb61fc2_49_ds_sys_struct.h"
#include "SmartRegulering_tester_cb61fc2_49_ds_log.h"
#include "SmartRegulering_tester_cb61fc2_49_ds.h"
#include "SmartRegulering_tester_cb61fc2_49_ds_externals.h"
#include "SmartRegulering_tester_cb61fc2_49_ds_external_struct.h"
#include "ssc_ml_fun.h"
int32_T SmartRegulering_tester_cb61fc2_49_ds_log ( const NeDynamicSystem *
sys , const NeDynamicSystemInput * t10 , NeDsMethodOutput * out ) { real_T
Jernbanenett_Current_Sensor10_I ; real_T Jernbanenett_Current_Sensor1_I ;
real_T Jernbanenett_Current_Sensor5_I ; real_T Jernbanenett_Current_Sensor6_I
; real_T Jernbanenett_Current_Sensor7_I ; real_T Jernbanenett_Inductor1_n_v ;
real_T Jernbanenett_Inductor2_n_v ; real_T Jernbanenett_Variable_Resistor2_v
; real_T Jernbanenett_Variable_Resistor3_v ; real_T t2 ;
Jernbanenett_Current_Sensor1_I = t10 -> mX . mX [ 6ULL ] + t10 -> mX . mX [
7ULL ] ; Jernbanenett_Current_Sensor10_I = - t10 -> mX . mX [ 0ULL ] + t10 ->
mX . mX [ 8ULL ] * - 1.0E-9 ; Jernbanenett_Current_Sensor5_I = t10 -> mX . mX
[ 11ULL ] * 1.0E-9 + t10 -> mX . mX [ 1ULL ] ; Jernbanenett_Current_Sensor6_I
= t10 -> mX . mX [ 12ULL ] * 1.0E-9 + t10 -> mX . mX [ 2ULL ] ;
Jernbanenett_Current_Sensor7_I = ( - t10 -> mX . mX [ 7ULL ] + t10 -> mX . mX
[ 11ULL ] * 1.0E-9 ) + t10 -> mX . mX [ 1ULL ] ; out -> mLOG . mX [ 47ULL ] =
- t10 -> mX . mX [ 6ULL ] - t10 -> mX . mX [ 7ULL ] ;
Jernbanenett_Inductor1_n_v = - t10 -> mX . mX [ 12ULL ] + t10 -> mX . mX [
9ULL ] ; Jernbanenett_Inductor2_n_v = - t10 -> mX . mX [ 11ULL ] + t10 -> mU
. mX [ 7ULL ] ; t2 = - t10 -> mX . mX [ 8ULL ] + t10 -> mX . mX [ 9ULL ] ;
out -> mLOG . mX [ 81ULL ] = Jernbanenett_Current_Sensor6_I *
Jernbanenett_Current_Sensor6_I * 7.1999999999999993 ; out -> mLOG . mX [
86ULL ] = Jernbanenett_Current_Sensor5_I * Jernbanenett_Current_Sensor5_I *
7.1999999999999993 ; out -> mLOG . mX [ 90ULL ] =
Jernbanenett_Current_Sensor10_I * Jernbanenett_Current_Sensor10_I * 60.2 ;
out -> mLOG . mX [ 122ULL ] = t10 -> mX . mX [ 6ULL ] * t10 -> mX . mX [
13ULL ] ; Jernbanenett_Variable_Resistor2_v = - t10 -> mX . mX [ 10ULL ] +
t10 -> mX . mX [ 14ULL ] ; out -> mLOG . mX [ 128ULL ] =
Jernbanenett_Current_Sensor1_I * Jernbanenett_Variable_Resistor2_v ;
Jernbanenett_Variable_Resistor3_v = - t10 -> mU . mX [ 7ULL ] + t10 -> mX .
mX [ 15ULL ] ; out -> mLOG . mX [ 134ULL ] = t10 -> mX . mX [ 7ULL ] *
Jernbanenett_Variable_Resistor3_v ; out -> mLOG . mX [ 0ULL ] =
Jernbanenett_Current_Sensor1_I ; out -> mLOG . mX [ 1ULL ] =
Jernbanenett_Current_Sensor1_I ; out -> mLOG . mX [ 2ULL ] = t10 -> mU . mX [
4ULL ] ; out -> mLOG . mX [ 3ULL ] = t10 -> mU . mX [ 4ULL ] ; out -> mLOG .
mX [ 4ULL ] = Jernbanenett_Current_Sensor10_I ; out -> mLOG . mX [ 5ULL ] =
Jernbanenett_Current_Sensor10_I ; out -> mLOG . mX [ 6ULL ] = t10 -> mX . mX
[ 9ULL ] ; out -> mLOG . mX [ 7ULL ] = t10 -> mX . mX [ 9ULL ] ; out -> mLOG
. mX [ 8ULL ] = Jernbanenett_Current_Sensor10_I ; out -> mLOG . mX [ 9ULL ] =
Jernbanenett_Current_Sensor1_I ; out -> mLOG . mX [ 10ULL ] = t10 -> mX . mX
[ 6ULL ] ; out -> mLOG . mX [ 11ULL ] = t10 -> mX . mX [ 6ULL ] ; out -> mLOG
. mX [ 12ULL ] = t10 -> mX . mX [ 10ULL ] ; out -> mLOG . mX [ 13ULL ] = t10
-> mX . mX [ 10ULL ] ; out -> mLOG . mX [ 14ULL ] = t10 -> mX . mX [ 6ULL ] ;
out -> mLOG . mX [ 15ULL ] = Jernbanenett_Current_Sensor1_I ; out -> mLOG .
mX [ 16ULL ] = Jernbanenett_Current_Sensor1_I ; out -> mLOG . mX [ 17ULL ] =
t10 -> mX . mX [ 10ULL ] ; out -> mLOG . mX [ 18ULL ] = t10 -> mX . mX [
10ULL ] ; out -> mLOG . mX [ 19ULL ] = Jernbanenett_Current_Sensor1_I ; out
-> mLOG . mX [ 20ULL ] = t10 -> mX . mX [ 7ULL ] ; out -> mLOG . mX [ 21ULL ]
= t10 -> mX . mX [ 7ULL ] ; out -> mLOG . mX [ 22ULL ] = t10 -> mX . mX [
10ULL ] ; out -> mLOG . mX [ 23ULL ] = t10 -> mX . mX [ 10ULL ] ; out -> mLOG
. mX [ 24ULL ] = t10 -> mX . mX [ 7ULL ] ; out -> mLOG . mX [ 25ULL ] =
Jernbanenett_Current_Sensor5_I ; out -> mLOG . mX [ 26ULL ] =
Jernbanenett_Current_Sensor5_I ; out -> mLOG . mX [ 27ULL ] = t10 -> mX . mX
[ 9ULL ] ; out -> mLOG . mX [ 28ULL ] = t10 -> mX . mX [ 9ULL ] ; out -> mLOG
. mX [ 29ULL ] = Jernbanenett_Current_Sensor5_I ; out -> mLOG . mX [ 30ULL ]
= Jernbanenett_Current_Sensor6_I ; out -> mLOG . mX [ 31ULL ] =
Jernbanenett_Current_Sensor6_I ; out -> mLOG . mX [ 32ULL ] = t10 -> mX . mX
[ 9ULL ] ; out -> mLOG . mX [ 33ULL ] = t10 -> mX . mX [ 9ULL ] ; out -> mLOG
. mX [ 34ULL ] = Jernbanenett_Current_Sensor6_I ; out -> mLOG . mX [ 35ULL ]
= Jernbanenett_Current_Sensor7_I ; out -> mLOG . mX [ 36ULL ] =
Jernbanenett_Current_Sensor7_I ; out -> mLOG . mX [ 37ULL ] = t10 -> mU . mX
[ 7ULL ] ; out -> mLOG . mX [ 38ULL ] = t10 -> mU . mX [ 7ULL ] ; out -> mLOG
. mX [ 39ULL ] = Jernbanenett_Current_Sensor7_I ; out -> mLOG . mX [ 40ULL ]
= - Jernbanenett_Current_Sensor6_I ; out -> mLOG . mX [ 41ULL ] = -
Jernbanenett_Current_Sensor6_I ; out -> mLOG . mX [ 42ULL ] = t10 -> mU . mX
[ 8ULL ] ; out -> mLOG . mX [ 43ULL ] = t10 -> mU . mX [ 8ULL ] ; out -> mLOG
. mX [ 44ULL ] = - Jernbanenett_Current_Sensor6_I ; out -> mLOG . mX [ 45ULL
] = t10 -> mU . mX [ 4ULL ] ; out -> mLOG . mX [ 46ULL ] = t10 -> mU . mX [
4ULL ] ; out -> mLOG . mX [ 48ULL ] = t10 -> mU . mX [ 4ULL ] ; out -> mLOG .
mX [ 49ULL ] = t10 -> mU . mX [ 4ULL ] ; out -> mLOG . mX [ 50ULL ] = t10 ->
mU . mX [ 4ULL ] ; out -> mLOG . mX [ 51ULL ] = -
Jernbanenett_Current_Sensor7_I ; out -> mLOG . mX [ 52ULL ] = t10 -> mU . mX
[ 7ULL ] ; out -> mLOG . mX [ 53ULL ] = t10 -> mU . mX [ 7ULL ] ; out -> mLOG
. mX [ 54ULL ] = t10 -> mU . mX [ 7ULL ] ; out -> mLOG . mX [ 55ULL ] =
Jernbanenett_Current_Sensor6_I ; out -> mLOG . mX [ 56ULL ] = t10 -> mU . mX
[ 8ULL ] ; out -> mLOG . mX [ 57ULL ] = t10 -> mU . mX [ 8ULL ] ; out -> mLOG
. mX [ 58ULL ] = t10 -> mU . mX [ 8ULL ] ; out -> mLOG . mX [ 59ULL ] =
Jernbanenett_Inductor1_n_v ; out -> mLOG . mX [ 60ULL ] = t10 -> mX . mX [
9ULL ] ; out -> mLOG . mX [ 61ULL ] = Jernbanenett_Current_Sensor6_I ; out ->
mLOG . mX [ 62ULL ] = t10 -> mX . mX [ 2ULL ] ; out -> mLOG . mX [ 63ULL ] =
t10 -> mX . mX [ 12ULL ] * t10 -> mX . mX [ 12ULL ] * 1.0000000000000002E-12
* 1000.0 ; out -> mLOG . mX [ 64ULL ] = t10 -> mX . mX [ 12ULL ] ; out ->
mLOG . mX [ 65ULL ] = Jernbanenett_Inductor2_n_v ; out -> mLOG . mX [ 66ULL ]
= t10 -> mU . mX [ 7ULL ] ; out -> mLOG . mX [ 67ULL ] =
Jernbanenett_Current_Sensor5_I ; out -> mLOG . mX [ 68ULL ] = t10 -> mX . mX
[ 1ULL ] ; out -> mLOG . mX [ 69ULL ] = t10 -> mX . mX [ 11ULL ] * t10 -> mX
. mX [ 11ULL ] * 1.0000000000000002E-12 * 1000.0 ; out -> mLOG . mX [ 70ULL ]
= t10 -> mX . mX [ 11ULL ] ; out -> mLOG . mX [ 71ULL ] = t2 ; out -> mLOG .
mX [ 72ULL ] = t10 -> mX . mX [ 9ULL ] ; out -> mLOG . mX [ 73ULL ] = -
Jernbanenett_Current_Sensor10_I ; out -> mLOG . mX [ 74ULL ] = t10 -> mX . mX
[ 0ULL ] ; out -> mLOG . mX [ 75ULL ] = t10 -> mX . mX [ 8ULL ] * t10 -> mX .
mX [ 8ULL ] * 1.0000000000000002E-12 * 1000.0 ; out -> mLOG . mX [ 76ULL ] =
t10 -> mX . mX [ 8ULL ] ; out -> mLOG . mX [ 77ULL ] =
Jernbanenett_Current_Sensor6_I ; out -> mLOG . mX [ 78ULL ] = t10 -> mU . mX
[ 8ULL ] ; out -> mLOG . mX [ 79ULL ] = Jernbanenett_Inductor1_n_v ; out ->
mLOG . mX [ 80ULL ] = Jernbanenett_Current_Sensor6_I * 7.1999999999999993 ;
out -> mLOG . mX [ 82ULL ] = Jernbanenett_Current_Sensor5_I ; out -> mLOG .
mX [ 83ULL ] = t10 -> mX . mX [ 9ULL ] ; out -> mLOG . mX [ 84ULL ] =
Jernbanenett_Inductor2_n_v ; out -> mLOG . mX [ 85ULL ] =
Jernbanenett_Current_Sensor5_I * 7.1999999999999993 ; out -> mLOG . mX [
87ULL ] = - Jernbanenett_Current_Sensor10_I ; out -> mLOG . mX [ 88ULL ] = t2
; out -> mLOG . mX [ 89ULL ] = Jernbanenett_Current_Sensor10_I * - 60.2 ; out
-> mLOG . mX [ 91ULL ] = t10 -> mU . mX [ 0ULL ] ; out -> mLOG . mX [ 92ULL ]
= t10 -> mU . mX [ 1ULL ] ; out -> mLOG . mX [ 93ULL ] = t10 -> mU . mX [
2ULL ] ; out -> mLOG . mX [ 94ULL ] = t10 -> mU . mX [ 3ULL ] ; out -> mLOG .
mX [ 95ULL ] = t10 -> mU . mX [ 4ULL ] ; out -> mLOG . mX [ 96ULL ] = t10 ->
mU . mX [ 5ULL ] ; out -> mLOG . mX [ 97ULL ] = t10 -> mU . mX [ 6ULL ] ; out
-> mLOG . mX [ 98ULL ] = t10 -> mU . mX [ 7ULL ] ; out -> mLOG . mX [ 99ULL ]
= t10 -> mU . mX [ 8ULL ] ; out -> mLOG . mX [ 100ULL ] = t10 -> mU . mX [
2ULL ] ; out -> mLOG . mX [ 101ULL ] = t10 -> mX . mX [ 6ULL ] ; out -> mLOG
. mX [ 102ULL ] = t10 -> mX . mX [ 13ULL ] ; out -> mLOG . mX [ 103ULL ] =
t10 -> mX . mX [ 10ULL ] ; out -> mLOG . mX [ 104ULL ] = t10 -> mX . mX [
3ULL ] ; out -> mLOG . mX [ 105ULL ] = ( t10 -> mX . mX [ 10ULL ] - t10 -> mX
. mX [ 13ULL ] ) * ( t10 -> mX . mX [ 10ULL ] - t10 -> mX . mX [ 13ULL ] ) *
1.0000000000000002E-12 * 1000.0 ; out -> mLOG . mX [ 106ULL ] = t10 -> mU .
mX [ 0ULL ] ; out -> mLOG . mX [ 107ULL ] = Jernbanenett_Current_Sensor1_I ;
out -> mLOG . mX [ 108ULL ] = t10 -> mX . mX [ 14ULL ] ; out -> mLOG . mX [
109ULL ] = t10 -> mU . mX [ 4ULL ] ; out -> mLOG . mX [ 110ULL ] = t10 -> mX
. mX [ 4ULL ] ; out -> mLOG . mX [ 111ULL ] = ( t10 -> mU . mX [ 4ULL ] - t10
-> mX . mX [ 14ULL ] ) * ( t10 -> mU . mX [ 4ULL ] - t10 -> mX . mX [ 14ULL ]
) * 1.0000000000000002E-12 * 1000.0 ; out -> mLOG . mX [ 112ULL ] = t10 -> mU
. mX [ 5ULL ] ; out -> mLOG . mX [ 113ULL ] = t10 -> mX . mX [ 7ULL ] ; out
-> mLOG . mX [ 114ULL ] = t10 -> mX . mX [ 15ULL ] ; out -> mLOG . mX [
115ULL ] = t10 -> mX . mX [ 10ULL ] ; out -> mLOG . mX [ 116ULL ] = t10 -> mX
. mX [ 5ULL ] ; out -> mLOG . mX [ 117ULL ] = ( t10 -> mX . mX [ 10ULL ] -
t10 -> mX . mX [ 15ULL ] ) * ( t10 -> mX . mX [ 10ULL ] - t10 -> mX . mX [
15ULL ] ) * 1.0000000000000002E-12 * 1000.0 ; out -> mLOG . mX [ 118ULL ] =
t10 -> mU . mX [ 3ULL ] ; out -> mLOG . mX [ 119ULL ] = t10 -> mX . mX [ 6ULL
] ; out -> mLOG . mX [ 120ULL ] = t10 -> mX . mX [ 13ULL ] ; out -> mLOG . mX
[ 121ULL ] = t10 -> mX . mX [ 13ULL ] ; out -> mLOG . mX [ 123ULL ] = t10 ->
mU . mX [ 1ULL ] ; out -> mLOG . mX [ 124ULL ] =
Jernbanenett_Current_Sensor1_I ; out -> mLOG . mX [ 125ULL ] = t10 -> mX . mX
[ 10ULL ] ; out -> mLOG . mX [ 126ULL ] = t10 -> mX . mX [ 14ULL ] ; out ->
mLOG . mX [ 127ULL ] = Jernbanenett_Variable_Resistor2_v ; out -> mLOG . mX [
129ULL ] = t10 -> mU . mX [ 6ULL ] ; out -> mLOG . mX [ 130ULL ] = t10 -> mX
. mX [ 7ULL ] ; out -> mLOG . mX [ 131ULL ] = t10 -> mU . mX [ 7ULL ] ; out
-> mLOG . mX [ 132ULL ] = t10 -> mX . mX [ 15ULL ] ; out -> mLOG . mX [
133ULL ] = Jernbanenett_Variable_Resistor3_v ; out -> mLOG . mX [ 135ULL ] =
t10 -> mU . mX [ 4ULL ] ; out -> mLOG . mX [ 136ULL ] = t10 -> mU . mX [ 4ULL
] ; out -> mLOG . mX [ 137ULL ] = t10 -> mU . mX [ 4ULL ] ; out -> mLOG . mX
[ 138ULL ] = t10 -> mU . mX [ 7ULL ] ; out -> mLOG . mX [ 139ULL ] = t10 ->
mU . mX [ 7ULL ] ; out -> mLOG . mX [ 140ULL ] = t10 -> mU . mX [ 7ULL ] ;
out -> mLOG . mX [ 141ULL ] = t10 -> mU . mX [ 8ULL ] ; out -> mLOG . mX [
142ULL ] = t10 -> mU . mX [ 8ULL ] ; out -> mLOG . mX [ 143ULL ] = t10 -> mU
. mX [ 8ULL ] ; ( void ) sys ; ( void ) out ; return 0 ; }
