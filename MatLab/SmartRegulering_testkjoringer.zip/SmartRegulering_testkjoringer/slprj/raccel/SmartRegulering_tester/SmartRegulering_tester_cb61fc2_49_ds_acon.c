#include "ne_ds.h"
#include "SmartRegulering_tester_cb61fc2_49_ds_sys_struct.h"
#include "SmartRegulering_tester_cb61fc2_49_ds_acon.h"
#include "SmartRegulering_tester_cb61fc2_49_ds.h"
#include "SmartRegulering_tester_cb61fc2_49_ds_externals.h"
#include "SmartRegulering_tester_cb61fc2_49_ds_external_struct.h"
#include "ssc_ml_fun.h"
int32_T SmartRegulering_tester_cb61fc2_49_ds_acon ( const NeDynamicSystem *
sys , const NeDynamicSystemInput * t47 , NeDsMethodOutput * out ) { ( void )
t47 ; out -> mACON . mX [ 1ULL ] = 1.0 ; out -> mACON . mX [ 2ULL ] = 1.0 ;
out -> mACON . mX [ 4ULL ] = 1.0 ; out -> mACON . mX [ 7ULL ] = 1.0 ; out ->
mACON . mX [ 10ULL ] = 0.016611296681063124 ; out -> mACON . mX [ 11ULL ] =
1.0E-9 ; out -> mACON . mX [ 12ULL ] = - 0.1388888888888889 ; out -> mACON .
mX [ 13ULL ] = 0.1388888888888889 ; out -> mACON . mX [ 14ULL ] = -
0.016611295681063121 ; out -> mACON . mX [ 15ULL ] = 1.0 ; out -> mACON . mX
[ 16ULL ] = 1.0 ; out -> mACON . mX [ 18ULL ] = 0.13888888988888889 ; out ->
mACON . mX [ 19ULL ] = - 1.0E-9 ; out -> mACON . mX [ 21ULL ] =
0.13888888988888889 ; out -> mACON . mX [ 0ULL ] = - 0.0 ; out -> mACON . mX
[ 3ULL ] = - 0.0 ; out -> mACON . mX [ 5ULL ] = - 1.0 ; out -> mACON . mX [
6ULL ] = - 0.0 ; out -> mACON . mX [ 8ULL ] = 1.0 ; out -> mACON . mX [ 9ULL
] = - 1.0 ; out -> mACON . mX [ 17ULL ] = - 1.0 ; out -> mACON . mX [ 20ULL ]
= - 1.0 ; out -> mACON . mX [ 22ULL ] = 1.0E-9 ; out -> mACON . mX [ 23ULL ]
= - 1.0 ; out -> mACON . mX [ 24ULL ] = - 1.0 ; out -> mACON . mX [ 25ULL ] =
- 1.0 ; ( void ) sys ; ( void ) out ; return 0 ; }
