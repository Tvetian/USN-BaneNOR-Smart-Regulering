#include "ne_ds.h"
#include "SmartRegulering_tester_cb61fc2_49_ds_sys_struct.h"
#include "SmartRegulering_tester_cb61fc2_49_ds_obs_all.h"
#include "SmartRegulering_tester_cb61fc2_49_ds.h"
#include "SmartRegulering_tester_cb61fc2_49_ds_externals.h"
#include "SmartRegulering_tester_cb61fc2_49_ds_external_struct.h"
#include "ssc_ml_fun.h"
int32_T SmartRegulering_tester_cb61fc2_49_ds_obs_all ( const NeDynamicSystem
* sys , const NeDynamicSystemInput * t10 , NeDsMethodOutput * out ) { real_T
Jernbanenett_Current_Sensor10_I ; real_T Jernbanenett_Current_Sensor1_I ;
real_T Jernbanenett_Current_Sensor5_I ; real_T Jernbanenett_Current_Sensor6_I
; real_T Jernbanenett_Current_Sensor7_I ; real_T Jernbanenett_Inductor1_n_v ;
real_T Jernbanenett_Inductor2_n_v ; real_T t2 ;
Jernbanenett_Current_Sensor1_I = t10 -> mX . mX [ 6ULL ] + t10 -> mX . mX [
7ULL ] ; Jernbanenett_Current_Sensor10_I = - t10 -> mX . mX [ 0ULL ] + t10 ->
mX . mX [ 8ULL ] * - 1.0E-9 ; Jernbanenett_Current_Sensor5_I = t10 -> mX . mX
[ 11ULL ] * 1.0E-9 + t10 -> mX . mX [ 1ULL ] ; Jernbanenett_Current_Sensor6_I
= t10 -> mX . mX [ 12ULL ] * 1.0E-9 + t10 -> mX . mX [ 2ULL ] ;
Jernbanenett_Current_Sensor7_I = ( - t10 -> mX . mX [ 7ULL ] + t10 -> mX . mX
[ 11ULL ] * 1.0E-9 ) + t10 -> mX . mX [ 1ULL ] ; out -> mOBS_ALL . mX [ 51ULL
] = - t10 -> mX . mX [ 6ULL ] - t10 -> mX . mX [ 7ULL ] ;
Jernbanenett_Inductor1_n_v = - t10 -> mX . mX [ 12ULL ] + t10 -> mX . mX [
9ULL ] ; Jernbanenett_Inductor2_n_v = - t10 -> mX . mX [ 11ULL ] + t10 -> mU
. mX [ 7ULL ] ; t2 = - t10 -> mX . mX [ 8ULL ] + t10 -> mX . mX [ 9ULL ] ;
out -> mOBS_ALL . mX [ 135ULL ] = t10 -> mX . mX [ 13ULL ] ; out -> mOBS_ALL
. mX [ 142ULL ] = - t10 -> mX . mX [ 10ULL ] + t10 -> mX . mX [ 14ULL ] ; out
-> mOBS_ALL . mX [ 149ULL ] = - t10 -> mU . mX [ 7ULL ] + t10 -> mX . mX [
15ULL ] ; out -> mOBS_ALL . mX [ 0ULL ] = Jernbanenett_Current_Sensor1_I ;
out -> mOBS_ALL . mX [ 1ULL ] = Jernbanenett_Current_Sensor1_I ; out ->
mOBS_ALL . mX [ 2ULL ] = t10 -> mU . mX [ 4ULL ] ; out -> mOBS_ALL . mX [
3ULL ] = t10 -> mU . mX [ 4ULL ] ; out -> mOBS_ALL . mX [ 4ULL ] =
Jernbanenett_Current_Sensor10_I ; out -> mOBS_ALL . mX [ 5ULL ] =
Jernbanenett_Current_Sensor10_I ; out -> mOBS_ALL . mX [ 6ULL ] = t10 -> mX .
mX [ 9ULL ] ; out -> mOBS_ALL . mX [ 7ULL ] = t10 -> mX . mX [ 9ULL ] ; out
-> mOBS_ALL . mX [ 8ULL ] = Jernbanenett_Current_Sensor10_I ; out -> mOBS_ALL
. mX [ 9ULL ] = Jernbanenett_Current_Sensor1_I ; out -> mOBS_ALL . mX [ 10ULL
] = t10 -> mX . mX [ 6ULL ] ; out -> mOBS_ALL . mX [ 11ULL ] = t10 -> mX . mX
[ 6ULL ] ; out -> mOBS_ALL . mX [ 12ULL ] = t10 -> mX . mX [ 10ULL ] ; out ->
mOBS_ALL . mX [ 13ULL ] = t10 -> mX . mX [ 10ULL ] ; out -> mOBS_ALL . mX [
14ULL ] = t10 -> mX . mX [ 6ULL ] ; out -> mOBS_ALL . mX [ 15ULL ] =
Jernbanenett_Current_Sensor1_I ; out -> mOBS_ALL . mX [ 16ULL ] =
Jernbanenett_Current_Sensor1_I ; out -> mOBS_ALL . mX [ 17ULL ] = t10 -> mX .
mX [ 10ULL ] ; out -> mOBS_ALL . mX [ 18ULL ] = t10 -> mX . mX [ 10ULL ] ;
out -> mOBS_ALL . mX [ 19ULL ] = Jernbanenett_Current_Sensor1_I ; out ->
mOBS_ALL . mX [ 20ULL ] = t10 -> mX . mX [ 7ULL ] ; out -> mOBS_ALL . mX [
21ULL ] = t10 -> mX . mX [ 7ULL ] ; out -> mOBS_ALL . mX [ 22ULL ] = t10 ->
mX . mX [ 10ULL ] ; out -> mOBS_ALL . mX [ 23ULL ] = t10 -> mX . mX [ 10ULL ]
; out -> mOBS_ALL . mX [ 24ULL ] = t10 -> mX . mX [ 7ULL ] ; out -> mOBS_ALL
. mX [ 25ULL ] = Jernbanenett_Current_Sensor5_I ; out -> mOBS_ALL . mX [
26ULL ] = Jernbanenett_Current_Sensor5_I ; out -> mOBS_ALL . mX [ 27ULL ] =
t10 -> mX . mX [ 9ULL ] ; out -> mOBS_ALL . mX [ 28ULL ] = t10 -> mX . mX [
9ULL ] ; out -> mOBS_ALL . mX [ 29ULL ] = Jernbanenett_Current_Sensor5_I ;
out -> mOBS_ALL . mX [ 30ULL ] = Jernbanenett_Current_Sensor6_I ; out ->
mOBS_ALL . mX [ 31ULL ] = Jernbanenett_Current_Sensor6_I ; out -> mOBS_ALL .
mX [ 32ULL ] = t10 -> mX . mX [ 9ULL ] ; out -> mOBS_ALL . mX [ 33ULL ] = t10
-> mX . mX [ 9ULL ] ; out -> mOBS_ALL . mX [ 34ULL ] =
Jernbanenett_Current_Sensor6_I ; out -> mOBS_ALL . mX [ 35ULL ] =
Jernbanenett_Current_Sensor7_I ; out -> mOBS_ALL . mX [ 36ULL ] =
Jernbanenett_Current_Sensor7_I ; out -> mOBS_ALL . mX [ 37ULL ] = t10 -> mU .
mX [ 7ULL ] ; out -> mOBS_ALL . mX [ 38ULL ] = t10 -> mU . mX [ 7ULL ] ; out
-> mOBS_ALL . mX [ 39ULL ] = Jernbanenett_Current_Sensor7_I ; out -> mOBS_ALL
. mX [ 40ULL ] = - Jernbanenett_Current_Sensor6_I ; out -> mOBS_ALL . mX [
41ULL ] = - Jernbanenett_Current_Sensor6_I ; out -> mOBS_ALL . mX [ 42ULL ] =
t10 -> mU . mX [ 8ULL ] ; out -> mOBS_ALL . mX [ 43ULL ] = t10 -> mU . mX [
8ULL ] ; out -> mOBS_ALL . mX [ 44ULL ] = - Jernbanenett_Current_Sensor6_I ;
out -> mOBS_ALL . mX [ 45ULL ] = 0.0 ; out -> mOBS_ALL . mX [ 46ULL ] = 0.0 ;
out -> mOBS_ALL . mX [ 47ULL ] = t10 -> mU . mX [ 4ULL ] ; out -> mOBS_ALL .
mX [ 48ULL ] = t10 -> mU . mX [ 4ULL ] ; out -> mOBS_ALL . mX [ 49ULL ] = 0.0
; out -> mOBS_ALL . mX [ 50ULL ] = 0.0 ; out -> mOBS_ALL . mX [ 52ULL ] = 0.0
; out -> mOBS_ALL . mX [ 53ULL ] = t10 -> mU . mX [ 4ULL ] ; out -> mOBS_ALL
. mX [ 54ULL ] = t10 -> mU . mX [ 4ULL ] ; out -> mOBS_ALL . mX [ 55ULL ] =
t10 -> mU . mX [ 4ULL ] ; out -> mOBS_ALL . mX [ 56ULL ] = -
Jernbanenett_Current_Sensor7_I ; out -> mOBS_ALL . mX [ 57ULL ] = 0.0 ; out
-> mOBS_ALL . mX [ 58ULL ] = t10 -> mU . mX [ 7ULL ] ; out -> mOBS_ALL . mX [
59ULL ] = t10 -> mU . mX [ 7ULL ] ; out -> mOBS_ALL . mX [ 60ULL ] = t10 ->
mU . mX [ 7ULL ] ; out -> mOBS_ALL . mX [ 61ULL ] =
Jernbanenett_Current_Sensor6_I ; out -> mOBS_ALL . mX [ 62ULL ] = 0.0 ; out
-> mOBS_ALL . mX [ 63ULL ] = t10 -> mU . mX [ 8ULL ] ; out -> mOBS_ALL . mX [
64ULL ] = t10 -> mU . mX [ 8ULL ] ; out -> mOBS_ALL . mX [ 65ULL ] = t10 ->
mU . mX [ 8ULL ] ; out -> mOBS_ALL . mX [ 66ULL ] = 0.0 ; out -> mOBS_ALL .
mX [ 67ULL ] = 0.0 ; out -> mOBS_ALL . mX [ 68ULL ] =
Jernbanenett_Inductor1_n_v ; out -> mOBS_ALL . mX [ 69ULL ] = t10 -> mX . mX
[ 9ULL ] ; out -> mOBS_ALL . mX [ 70ULL ] = Jernbanenett_Current_Sensor6_I ;
out -> mOBS_ALL . mX [ 71ULL ] = t10 -> mX . mX [ 2ULL ] ; out -> mOBS_ALL .
mX [ 72ULL ] = t10 -> mX . mX [ 12ULL ] * t10 -> mX . mX [ 12ULL ] *
1.0000000000000002E-12 * 1000.0 ; out -> mOBS_ALL . mX [ 73ULL ] = t10 -> mX
. mX [ 12ULL ] ; out -> mOBS_ALL . mX [ 74ULL ] = 0.0 ; out -> mOBS_ALL . mX
[ 75ULL ] = 0.0 ; out -> mOBS_ALL . mX [ 76ULL ] = Jernbanenett_Inductor2_n_v
; out -> mOBS_ALL . mX [ 77ULL ] = t10 -> mU . mX [ 7ULL ] ; out -> mOBS_ALL
. mX [ 78ULL ] = Jernbanenett_Current_Sensor5_I ; out -> mOBS_ALL . mX [
79ULL ] = t10 -> mX . mX [ 1ULL ] ; out -> mOBS_ALL . mX [ 80ULL ] = t10 ->
mX . mX [ 11ULL ] * t10 -> mX . mX [ 11ULL ] * 1.0000000000000002E-12 *
1000.0 ; out -> mOBS_ALL . mX [ 81ULL ] = t10 -> mX . mX [ 11ULL ] ; out ->
mOBS_ALL . mX [ 82ULL ] = 0.0 ; out -> mOBS_ALL . mX [ 83ULL ] = 0.0 ; out ->
mOBS_ALL . mX [ 84ULL ] = t2 ; out -> mOBS_ALL . mX [ 85ULL ] = t10 -> mX .
mX [ 9ULL ] ; out -> mOBS_ALL . mX [ 86ULL ] = -
Jernbanenett_Current_Sensor10_I ; out -> mOBS_ALL . mX [ 87ULL ] = t10 -> mX
. mX [ 0ULL ] ; out -> mOBS_ALL . mX [ 88ULL ] = t10 -> mX . mX [ 8ULL ] *
t10 -> mX . mX [ 8ULL ] * 1.0000000000000002E-12 * 1000.0 ; out -> mOBS_ALL .
mX [ 89ULL ] = t10 -> mX . mX [ 8ULL ] ; out -> mOBS_ALL . mX [ 90ULL ] =
Jernbanenett_Current_Sensor6_I ; out -> mOBS_ALL . mX [ 91ULL ] = t10 -> mU .
mX [ 8ULL ] ; out -> mOBS_ALL . mX [ 92ULL ] = Jernbanenett_Inductor1_n_v ;
out -> mOBS_ALL . mX [ 93ULL ] = Jernbanenett_Current_Sensor6_I *
7.1999999999999993 ; out -> mOBS_ALL . mX [ 94ULL ] =
Jernbanenett_Current_Sensor5_I ; out -> mOBS_ALL . mX [ 95ULL ] = t10 -> mX .
mX [ 9ULL ] ; out -> mOBS_ALL . mX [ 96ULL ] = Jernbanenett_Inductor2_n_v ;
out -> mOBS_ALL . mX [ 97ULL ] = Jernbanenett_Current_Sensor5_I *
7.1999999999999993 ; out -> mOBS_ALL . mX [ 98ULL ] = -
Jernbanenett_Current_Sensor10_I ; out -> mOBS_ALL . mX [ 99ULL ] = 0.0 ; out
-> mOBS_ALL . mX [ 100ULL ] = t2 ; out -> mOBS_ALL . mX [ 101ULL ] =
Jernbanenett_Current_Sensor10_I * - 60.2 ; out -> mOBS_ALL . mX [ 102ULL ] =
t10 -> mU . mX [ 0ULL ] ; out -> mOBS_ALL . mX [ 103ULL ] = t10 -> mU . mX [
1ULL ] ; out -> mOBS_ALL . mX [ 104ULL ] = t10 -> mU . mX [ 2ULL ] ; out ->
mOBS_ALL . mX [ 105ULL ] = t10 -> mU . mX [ 3ULL ] ; out -> mOBS_ALL . mX [
106ULL ] = t10 -> mU . mX [ 4ULL ] ; out -> mOBS_ALL . mX [ 107ULL ] = t10 ->
mU . mX [ 5ULL ] ; out -> mOBS_ALL . mX [ 108ULL ] = t10 -> mU . mX [ 6ULL ]
; out -> mOBS_ALL . mX [ 109ULL ] = t10 -> mU . mX [ 7ULL ] ; out -> mOBS_ALL
. mX [ 110ULL ] = t10 -> mU . mX [ 8ULL ] ; out -> mOBS_ALL . mX [ 111ULL ] =
t10 -> mU . mX [ 2ULL ] ; out -> mOBS_ALL . mX [ 112ULL ] = t10 -> mX . mX [
6ULL ] ; out -> mOBS_ALL . mX [ 113ULL ] = t10 -> mX . mX [ 13ULL ] ; out ->
mOBS_ALL . mX [ 114ULL ] = t10 -> mX . mX [ 10ULL ] ; out -> mOBS_ALL . mX [
115ULL ] = t10 -> mX . mX [ 3ULL ] ; out -> mOBS_ALL . mX [ 116ULL ] = ( t10
-> mX . mX [ 10ULL ] - t10 -> mX . mX [ 13ULL ] ) * ( t10 -> mX . mX [ 10ULL
] - t10 -> mX . mX [ 13ULL ] ) * 1.0000000000000002E-12 * 1000.0 ; out ->
mOBS_ALL . mX [ 117ULL ] = t10 -> mU . mX [ 0ULL ] ; out -> mOBS_ALL . mX [
118ULL ] = Jernbanenett_Current_Sensor1_I ; out -> mOBS_ALL . mX [ 119ULL ] =
t10 -> mX . mX [ 14ULL ] ; out -> mOBS_ALL . mX [ 120ULL ] = t10 -> mU . mX [
4ULL ] ; out -> mOBS_ALL . mX [ 121ULL ] = t10 -> mX . mX [ 4ULL ] ; out ->
mOBS_ALL . mX [ 122ULL ] = ( t10 -> mU . mX [ 4ULL ] - t10 -> mX . mX [ 14ULL
] ) * ( t10 -> mU . mX [ 4ULL ] - t10 -> mX . mX [ 14ULL ] ) *
1.0000000000000002E-12 * 1000.0 ; out -> mOBS_ALL . mX [ 123ULL ] = t10 -> mU
. mX [ 5ULL ] ; out -> mOBS_ALL . mX [ 124ULL ] = t10 -> mX . mX [ 7ULL ] ;
out -> mOBS_ALL . mX [ 125ULL ] = t10 -> mX . mX [ 15ULL ] ; out -> mOBS_ALL
. mX [ 126ULL ] = t10 -> mX . mX [ 10ULL ] ; out -> mOBS_ALL . mX [ 127ULL ]
= t10 -> mX . mX [ 5ULL ] ; out -> mOBS_ALL . mX [ 128ULL ] = ( t10 -> mX .
mX [ 10ULL ] - t10 -> mX . mX [ 15ULL ] ) * ( t10 -> mX . mX [ 10ULL ] - t10
-> mX . mX [ 15ULL ] ) * 1.0000000000000002E-12 * 1000.0 ; out -> mOBS_ALL .
mX [ 129ULL ] = 0.0 ; out -> mOBS_ALL . mX [ 130ULL ] = t10 -> mU . mX [ 3ULL
] ; out -> mOBS_ALL . mX [ 131ULL ] = 0.0 ; out -> mOBS_ALL . mX [ 132ULL ] =
t10 -> mX . mX [ 6ULL ] ; out -> mOBS_ALL . mX [ 133ULL ] = 0.0 ; out ->
mOBS_ALL . mX [ 134ULL ] = t10 -> mX . mX [ 13ULL ] ; out -> mOBS_ALL . mX [
136ULL ] = 0.0 ; out -> mOBS_ALL . mX [ 137ULL ] = t10 -> mU . mX [ 1ULL ] ;
out -> mOBS_ALL . mX [ 138ULL ] = 0.0 ; out -> mOBS_ALL . mX [ 139ULL ] =
Jernbanenett_Current_Sensor1_I ; out -> mOBS_ALL . mX [ 140ULL ] = t10 -> mX
. mX [ 10ULL ] ; out -> mOBS_ALL . mX [ 141ULL ] = t10 -> mX . mX [ 14ULL ] ;
out -> mOBS_ALL . mX [ 143ULL ] = 0.0 ; out -> mOBS_ALL . mX [ 144ULL ] = t10
-> mU . mX [ 6ULL ] ; out -> mOBS_ALL . mX [ 145ULL ] = 0.0 ; out -> mOBS_ALL
. mX [ 146ULL ] = t10 -> mX . mX [ 7ULL ] ; out -> mOBS_ALL . mX [ 147ULL ] =
t10 -> mU . mX [ 7ULL ] ; out -> mOBS_ALL . mX [ 148ULL ] = t10 -> mX . mX [
15ULL ] ; out -> mOBS_ALL . mX [ 150ULL ] = t10 -> mU . mX [ 4ULL ] ; out ->
mOBS_ALL . mX [ 151ULL ] = 0.0 ; out -> mOBS_ALL . mX [ 152ULL ] = t10 -> mU
. mX [ 4ULL ] ; out -> mOBS_ALL . mX [ 153ULL ] = t10 -> mU . mX [ 4ULL ] ;
out -> mOBS_ALL . mX [ 154ULL ] = t10 -> mU . mX [ 7ULL ] ; out -> mOBS_ALL .
mX [ 155ULL ] = 0.0 ; out -> mOBS_ALL . mX [ 156ULL ] = t10 -> mU . mX [ 7ULL
] ; out -> mOBS_ALL . mX [ 157ULL ] = t10 -> mU . mX [ 7ULL ] ; out ->
mOBS_ALL . mX [ 158ULL ] = t10 -> mU . mX [ 8ULL ] ; out -> mOBS_ALL . mX [
159ULL ] = 0.0 ; out -> mOBS_ALL . mX [ 160ULL ] = t10 -> mU . mX [ 8ULL ] ;
out -> mOBS_ALL . mX [ 161ULL ] = t10 -> mU . mX [ 8ULL ] ; ( void ) sys ; ( void ) out ; return 0 ; }
