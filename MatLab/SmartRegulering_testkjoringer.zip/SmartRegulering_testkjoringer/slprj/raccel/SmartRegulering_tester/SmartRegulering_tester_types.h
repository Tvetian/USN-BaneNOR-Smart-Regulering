#ifndef SmartRegulering_tester_types_h_
#define SmartRegulering_tester_types_h_
#include "rtwtypes.h"
#ifndef DEFINED_TYPEDEF_FOR_struct_nxjvkMAWNMdcRzZZdKzTgC_
#define DEFINED_TYPEDEF_FOR_struct_nxjvkMAWNMdcRzZZdKzTgC_
typedef struct { real_T Freq ; real_T n ; real_T k ; real_T Real_Init ;
real_T Imag_Init ; } struct_nxjvkMAWNMdcRzZZdKzTgC ;
#endif
#ifndef DEFINED_TYPEDEF_FOR_struct_UskKbK8yRC8GsXIo0cWURE_
#define DEFINED_TYPEDEF_FOR_struct_UskKbK8yRC8GsXIo0cWURE_
typedef struct { real_T Freq ; real_T Vinit ; real_T Delay ; real_T K1 ;
real_T K2 ; } struct_UskKbK8yRC8GsXIo0cWURE ;
#endif
#ifndef DEFINED_TYPEDEF_FOR_struct_KstRuYZ23rWaam7stFsSgH_
#define DEFINED_TYPEDEF_FOR_struct_KstRuYZ23rWaam7stFsSgH_
typedef struct { real_T Freq ; real_T Par_Vinit [ 2 ] ; real_T Par_Iinit [ 2
] ; } struct_KstRuYZ23rWaam7stFsSgH ;
#endif
#ifndef SS_UINT64
#define SS_UINT64 20
#endif
#ifndef SS_INT64
#define SS_INT64 21
#endif
typedef struct P_ P ;
#endif
