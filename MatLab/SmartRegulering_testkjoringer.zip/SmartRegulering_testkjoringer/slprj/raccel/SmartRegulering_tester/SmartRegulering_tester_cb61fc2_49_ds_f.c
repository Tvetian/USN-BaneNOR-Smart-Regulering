#include "ne_ds.h"
#include "SmartRegulering_tester_cb61fc2_49_ds_sys_struct.h"
#include "SmartRegulering_tester_cb61fc2_49_ds_f.h"
#include "SmartRegulering_tester_cb61fc2_49_ds.h"
#include "SmartRegulering_tester_cb61fc2_49_ds_externals.h"
#include "SmartRegulering_tester_cb61fc2_49_ds_external_struct.h"
#include "ssc_ml_fun.h"
int32_T SmartRegulering_tester_cb61fc2_49_ds_f ( const NeDynamicSystem * sys
, const NeDynamicSystemInput * t13 , NeDsMethodOutput * out ) { real_T
Jernbanenett_Current_Sensor1_I ; real_T Jernbanenett_Current_Sensor1_n_v ;
real_T Jernbanenett_Variable_Resistor2_v ; real_T
Jernbanenett_Variable_Resistor3_v ; real_T t0 ; real_T t1 ; real_T t2 ;
Jernbanenett_Current_Sensor1_I = t13 -> mX . mX [ 6ULL ] + t13 -> mX . mX [
7ULL ] ; Jernbanenett_Variable_Resistor2_v = - t13 -> mX . mX [ 10ULL ] + t13
-> mX . mX [ 14ULL ] ; Jernbanenett_Variable_Resistor3_v = - t13 -> mU . mX [
7ULL ] + t13 -> mX . mX [ 15ULL ] ; t1 = t13 -> mX . mX [ 10ULL ] - t13 -> mX
. mX [ 13ULL ] ; t2 = t13 -> mU . mX [ 4ULL ] - t13 -> mX . mX [ 14ULL ] ;
Jernbanenett_Current_Sensor1_n_v = t13 -> mX . mX [ 10ULL ] - t13 -> mX . mX
[ 15ULL ] ; if ( t13 -> mM . mX [ 0ULL ] != 0 ) { t0 = t13 -> mX . mX [ 6ULL
] - ( t1 * 1.0E-9 + t13 -> mX . mX [ 3ULL ] / ( t13 -> mU . mX [ 2ULL ] ==
0.0 ? 1.0E-16 : t13 -> mU . mX [ 2ULL ] ) ) ; } else { t0 = t13 -> mX . mX [
6ULL ] - ( t1 * 1.0E-9 + t13 -> mX . mX [ 3ULL ] / 1.0E-6 ) ; } if ( t13 ->
mM . mX [ 1ULL ] != 0 ) { t1 = Jernbanenett_Current_Sensor1_I - ( t2 * 1.0E-9
+ t13 -> mX . mX [ 4ULL ] / ( t13 -> mU . mX [ 0ULL ] == 0.0 ? 1.0E-16 : t13
-> mU . mX [ 0ULL ] ) ) ; } else { t1 = Jernbanenett_Current_Sensor1_I - ( t2
* 1.0E-9 + t13 -> mX . mX [ 4ULL ] / 1.0E-6 ) ; } if ( t13 -> mM . mX [ 2ULL
] != 0 ) { t2 = t13 -> mX . mX [ 7ULL ] - ( Jernbanenett_Current_Sensor1_n_v
* 1.0E-9 + t13 -> mX . mX [ 5ULL ] / ( t13 -> mU . mX [ 5ULL ] == 0.0 ?
1.0E-16 : t13 -> mU . mX [ 5ULL ] ) ) ; } else { t2 = t13 -> mX . mX [ 7ULL ]
- ( Jernbanenett_Current_Sensor1_n_v * 1.0E-9 + t13 -> mX . mX [ 5ULL ] /
1.0E-6 ) ; } if ( t13 -> mM . mX [ 3ULL ] != 0 ) { out -> mF . mX [ 12ULL ] =
t13 -> mX . mX [ 13ULL ] - t13 -> mU . mX [ 3ULL ] * t13 -> mX . mX [ 6ULL ]
; } else { out -> mF . mX [ 12ULL ] = t13 -> mX . mX [ 13ULL ] ; } if ( t13
-> mM . mX [ 4ULL ] != 0 ) { out -> mF . mX [ 13ULL ] =
Jernbanenett_Variable_Resistor2_v - Jernbanenett_Current_Sensor1_I * t13 ->
mU . mX [ 1ULL ] ; } else { out -> mF . mX [ 13ULL ] =
Jernbanenett_Variable_Resistor2_v ; } if ( t13 -> mM . mX [ 5ULL ] != 0 ) {
out -> mF . mX [ 14ULL ] = Jernbanenett_Variable_Resistor3_v - t13 -> mU . mX
[ 6ULL ] * t13 -> mX . mX [ 7ULL ] ; } else { out -> mF . mX [ 14ULL ] =
Jernbanenett_Variable_Resistor3_v ; } out -> mF . mX [ 0ULL ] = - 0.0 ; out
-> mF . mX [ 1ULL ] = - 0.0 ; out -> mF . mX [ 2ULL ] = - 0.0 ; out -> mF .
mX [ 3ULL ] = - 0.0 ; out -> mF . mX [ 4ULL ] = - 0.0 ; out -> mF . mX [ 5ULL
] = - 0.0 ; out -> mF . mX [ 6ULL ] = 0.0 ; out -> mF . mX [ 7ULL ] = 0.0 ;
out -> mF . mX [ 8ULL ] = 0.0 ; out -> mF . mX [ 9ULL ] = t0 / 1.0E+6 ; out
-> mF . mX [ 10ULL ] = t1 / 1.0E+6 ; out -> mF . mX [ 11ULL ] = t2 / 1.0E+6 ;
out -> mF . mX [ 15ULL ] = - 0.0 ; ( void ) sys ; ( void ) out ; return 0 ; }
