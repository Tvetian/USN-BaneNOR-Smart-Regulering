#ifndef SmartRegulering_tester_private_h_
#define SmartRegulering_tester_private_h_
#include "rtwtypes.h"
#include "builtin_typeid_types.h"
#include "multiword_types.h"
#include "SmartRegulering_tester.h"
#include "SmartRegulering_tester_types.h"
#if !defined(rt_VALIDATE_MEMORY)
#define rt_VALIDATE_MEMORY(S, ptr)     if(!(ptr)) {\
    ssSetErrorStatus(rtS, RT_MEMORY_ALLOCATION_ERROR);\
    }
#endif
#if !defined(rt_FREE)
#if !defined(_WIN32)
#define rt_FREE(ptr)     if((ptr) != (NULL)) {\
    free((ptr));\
    (ptr) = (NULL);\
    }
#else
#define rt_FREE(ptr)     if((ptr) != (NULL)) {\
    free((void *)(ptr));\
    (ptr) = (NULL);\
    }
#endif
#endif
#ifndef rtInterpolate
#define rtInterpolate(v1,v2,f1,f2)     (((v1)==(v2))?((double)(v1)):    (((f1)*((double)(v1)))+((f2)*((double)(v2)))))
#endif
#ifndef rtRound
#define rtRound(v) ( ((v) >= 0) ?     muDoubleScalarFloor((v) + 0.5) :     muDoubleScalarCeil((v) - 0.5) )
#endif
extern void sfun_discreteVariableDelay ( SimStruct * rts ) ; extern void
o51ctwcjrv ( fdcbb0y42l * localDW ) ; extern void n1gc4ida2j ( real_T
ce2mpwb3wh , real_T mbltc2zrhs , d5m2sruhhf * localB , fdcbb0y42l * localDW )
; extern void fsekeb1zuj ( ia5kdmyurt * localDW ) ; extern void ifpkh5twxl ( real_T olrere2ht5 , real_T gief1zzzbv , lklpfh14jj * localB , ia5kdmyurt * localDW ) ; extern void lmnnh0usyy ( gqs0umc0mk * localDW ) ; extern void dz2db40zz4 ( real_T geej0wwra3 , real_T hximeoglwy , b4f4jmei5g * localB , gqs0umc0mk * localDW ) ; extern void cffale1lb3 ( bo2rcapilx * localDW ) ; extern void bg5x2ek5qe ( real_T ar4wdcv4qd , real_T ilw5vzlvdg , bccvt1f3jl * localB , bo2rcapilx * localDW ) ; extern void bbomouosgl ( fdb0h3mfdt * localDW ) ; extern void g15lgrelck ( real_T hy0kohadm5 , real_T cn5kvh5qhc , elj0vvggqz * localB , fdb0h3mfdt * localDW ) ; extern void o1dkaojcq3 ( evmay4lb11 * localDW ) ; extern void ek5wot2buf ( real_T n13wjwy4sp , real_T d3g2ngz2rt , mlifxjqchg * localB , evmay4lb11 * localDW ) ; extern void eva55qr4yz ( aebc5nni5e * localDW ) ; extern void po0ojeaga2 ( real_T jp3ol0q3b0 , real_T c2cpulbscf , knoh2sinhx * localB , aebc5nni5e * localDW ) ; extern void ol0btcyygc ( fb5fdsqqiv * localDW ) ; extern void dy0tqnllxf ( real_T gpss2meyab , real_T ec3lqgvgeh , nl4zpk1eqy * localB , fb5fdsqqiv * localDW ) ; extern void hglzf2nvpl ( jc3ntcshin * localDW ) ; extern void kwmydtm1la ( real_T dirly23eyi , ozibq4u3w2 * localB , jc3ntcshin * localDW ) ; extern void bsjxscuojj ( hg0nn3kt4f * localDW ) ; extern void i4viggxat4 ( real_T mphjmis3eo , real_T a4tue3taru , n0mdiepyi2 * localB , hg0nn3kt4f * localDW ) ; extern void kglh3nohdv ( ob4styofv5 * localDW ) ; extern void jhsytim52c ( real_T opdme2cudj , real_T ig2jesehez , mmy4vttj4h * localB , ob4styofv5 * localDW ) ; extern void pkz1wpjxdi ( ipbeol0lq3 * localDW ) ; extern void ilz02ztmmv ( ipbeol0lq3 * localDW ) ;
#if defined(MULTITASKING)
#error Model (SmartRegulering_tester) was built in \SingleTasking solver mode, however the MULTITASKING define is \present. If you have multitasking (e.g. -DMT or -DMULTITASKING) \defined on the Code Generation page of Simulation parameter dialog, please \remove it and on the Solver page, select solver mode \MultiTasking. If the Simulation parameter dialog is configured \correctly, please verify that your template makefile is \configured correctly.
#endif
#endif
