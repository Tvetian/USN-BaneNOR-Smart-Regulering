#ifndef rtmodel_h_
#define rtmodel_h_
#include "SmartRegulering_tester.h"
#define GRTINTERFACE 1
#endif
