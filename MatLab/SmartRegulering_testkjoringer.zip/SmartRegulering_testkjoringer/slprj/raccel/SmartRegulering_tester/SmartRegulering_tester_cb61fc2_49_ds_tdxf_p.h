#ifdef __cplusplus
extern "C" {
#endif
#ifndef SMARTREGULERING_TESTER_CB61FC2_49_DS_TDXF_P_H
#define SMARTREGULERING_TESTER_CB61FC2_49_DS_TDXF_P_H 1
int32_T SmartRegulering_tester_cb61fc2_49_ds_tdxf_p ( const NeDynamicSystem *
sys , const NeDynamicSystemInput * Q , NeDsMethodOutput * M ) ;
#endif
#ifdef __cplusplus
}
#endif
