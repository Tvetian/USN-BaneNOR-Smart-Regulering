#include "ne_ds.h"
#include "SmartRegulering_tester_cb61fc2_49_ds_sys_struct.h"
#include "SmartRegulering_tester_cb61fc2_49_ds_assert.h"
#include "SmartRegulering_tester_cb61fc2_49_ds.h"
#include "SmartRegulering_tester_cb61fc2_49_ds_externals.h"
#include "SmartRegulering_tester_cb61fc2_49_ds_external_struct.h"
#include "ssc_ml_fun.h"
int32_T SmartRegulering_tester_cb61fc2_49_ds_assert ( const NeDynamicSystem *
sys , const NeDynamicSystemInput * t1 , NeDsMethodOutput * out ) { out ->
mASSERT . mX [ 0ULL ] = 1 ; out -> mASSERT . mX [ 1ULL ] = 1 ; out -> mASSERT
. mX [ 2ULL ] = 1 ; out -> mASSERT . mX [ 3ULL ] = 1 ; out -> mASSERT . mX [
4ULL ] = 1 ; out -> mASSERT . mX [ 5ULL ] = 1 ; out -> mASSERT . mX [ 6ULL ]
= 1 ; out -> mASSERT . mX [ 7ULL ] = 1 ; out -> mASSERT . mX [ 8ULL ] = 1 ;
out -> mASSERT . mX [ 9ULL ] = 1 ; out -> mASSERT . mX [ 10ULL ] = 1 ; out ->
mASSERT . mX [ 11ULL ] = 1 ; out -> mASSERT . mX [ 12ULL ] = 1 ; out ->
mASSERT . mX [ 13ULL ] = 1 ; out -> mASSERT . mX [ 14ULL ] = 1 ; out ->
mASSERT . mX [ 15ULL ] = 1 ; out -> mASSERT . mX [ 16ULL ] = 1 ; out ->
mASSERT . mX [ 17ULL ] = 1 ; out -> mASSERT . mX [ 18ULL ] = 1 ; out ->
mASSERT . mX [ 19ULL ] = 1 ; out -> mASSERT . mX [ 20ULL ] = 1 ; out ->
mASSERT . mX [ 21ULL ] = 1 ; out -> mASSERT . mX [ 22ULL ] = 1 ; out ->
mASSERT . mX [ 23ULL ] = 1 ; out -> mASSERT . mX [ 24ULL ] = ( int32_T ) ( ( !
( t1 -> mU . mX [ 2ULL ] > 1.0E-6 ) ) || ( t1 -> mU . mX [ 2ULL ] != 0.0 ) )
; out -> mASSERT . mX [ 25ULL ] = 1 ; out -> mASSERT . mX [ 26ULL ] = ( int32_T
) ( ( ! ( t1 -> mU . mX [ 0ULL ] > 1.0E-6 ) ) || ( t1 -> mU . mX [ 0ULL ] !=
0.0 ) ) ; out -> mASSERT . mX [ 27ULL ] = 1 ; out -> mASSERT . mX [ 28ULL ] =
( int32_T ) ( ( ! ( t1 -> mU . mX [ 5ULL ] > 1.0E-6 ) ) || ( t1 -> mU . mX [
5ULL ] != 0.0 ) ) ; out -> mASSERT . mX [ 29ULL ] = 1 ; ( void ) sys ; ( void
) out ; return 0 ; }
