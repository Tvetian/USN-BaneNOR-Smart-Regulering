#include "ne_ds.h"
#include "SmartRegulering_tester_cb61fc2_49_ds_sys_struct.h"
#include "SmartRegulering_tester_cb61fc2_49_ds_y.h"
#include "SmartRegulering_tester_cb61fc2_49_ds.h"
#include "SmartRegulering_tester_cb61fc2_49_ds_externals.h"
#include "SmartRegulering_tester_cb61fc2_49_ds_external_struct.h"
#include "ssc_ml_fun.h"
int32_T SmartRegulering_tester_cb61fc2_49_ds_y ( const NeDynamicSystem * sys
, const NeDynamicSystemInput * t3 , NeDsMethodOutput * out ) { real_T
Jernbanenett_Current_Sensor1_I ; real_T Jernbanenett_Current_Sensor6_I ;
Jernbanenett_Current_Sensor1_I = t3 -> mX . mX [ 6ULL ] + t3 -> mX . mX [
7ULL ] ; out -> mY . mX [ 0ULL ] = - t3 -> mX . mX [ 0ULL ] + t3 -> mX . mX [
8ULL ] * - 1.0E-9 ; out -> mY . mX [ 5ULL ] = t3 -> mX . mX [ 11ULL ] *
1.0E-9 + t3 -> mX . mX [ 1ULL ] ; Jernbanenett_Current_Sensor6_I = t3 -> mX .
mX [ 12ULL ] * 1.0E-9 + t3 -> mX . mX [ 2ULL ] ; out -> mY . mX [ 7ULL ] = ( -
t3 -> mX . mX [ 7ULL ] + t3 -> mX . mX [ 11ULL ] * 1.0E-9 ) + t3 -> mX . mX [
1ULL ] ; out -> mY . mX [ 10ULL ] = t3 -> mU . mX [ 4ULL ] ; out -> mY . mX [
11ULL ] = t3 -> mU . mX [ 7ULL ] ; out -> mY . mX [ 12ULL ] = t3 -> mU . mX [
8ULL ] ; out -> mY . mX [ 1ULL ] = Jernbanenett_Current_Sensor1_I ; out -> mY
. mX [ 2ULL ] = t3 -> mX . mX [ 6ULL ] ; out -> mY . mX [ 3ULL ] =
Jernbanenett_Current_Sensor1_I ; out -> mY . mX [ 4ULL ] = t3 -> mX . mX [
7ULL ] ; out -> mY . mX [ 6ULL ] = Jernbanenett_Current_Sensor6_I ; out -> mY
. mX [ 8ULL ] = - Jernbanenett_Current_Sensor6_I ; out -> mY . mX [ 9ULL ] =
0.0 ; ( void ) sys ; ( void ) out ; return 0 ; }
