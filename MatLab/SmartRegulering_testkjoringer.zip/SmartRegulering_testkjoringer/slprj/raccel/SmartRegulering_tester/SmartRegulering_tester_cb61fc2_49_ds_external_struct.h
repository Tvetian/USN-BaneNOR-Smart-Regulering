#ifndef struct__ExternalFunctionStructTag
#define struct__ExternalFunctionStructTag
#endif
