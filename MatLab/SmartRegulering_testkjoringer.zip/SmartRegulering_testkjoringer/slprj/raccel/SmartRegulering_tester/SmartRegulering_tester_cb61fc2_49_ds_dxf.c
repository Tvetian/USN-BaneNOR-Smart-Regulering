#include "ne_ds.h"
#include "SmartRegulering_tester_cb61fc2_49_ds_sys_struct.h"
#include "SmartRegulering_tester_cb61fc2_49_ds_dxf.h"
#include "SmartRegulering_tester_cb61fc2_49_ds.h"
#include "SmartRegulering_tester_cb61fc2_49_ds_externals.h"
#include "SmartRegulering_tester_cb61fc2_49_ds_external_struct.h"
#include "ssc_ml_fun.h"
int32_T SmartRegulering_tester_cb61fc2_49_ds_dxf ( const NeDynamicSystem *
sys , const NeDynamicSystemInput * t35 , NeDsMethodOutput * out ) { real_T t6
[ 4 ] ; real_T t7 [ 4 ] ; real_T t0 ; real_T t2 ; real_T t27 ; size_t t12 ;
if ( t35 -> mM . mX [ 0ULL ] != 0 ) { t0 = - ( 1.0 / ( t35 -> mU . mX [ 2ULL
] == 0.0 ? 1.0E-16 : t35 -> mU . mX [ 2ULL ] ) ) ; } else { t0 = - 1.0E+6 ; }
if ( t35 -> mM . mX [ 1ULL ] != 0 ) { t27 = - ( 1.0 / ( t35 -> mU . mX [ 0ULL
] == 0.0 ? 1.0E-16 : t35 -> mU . mX [ 0ULL ] ) ) ; } else { t27 = - 1.0E+6 ;
} if ( t35 -> mM . mX [ 2ULL ] != 0 ) { t2 = - ( 1.0 / ( t35 -> mU . mX [
5ULL ] == 0.0 ? 1.0E-16 : t35 -> mU . mX [ 5ULL ] ) ) ; } else { t2 = -
1.0E+6 ; } if ( t35 -> mM . mX [ 4ULL ] != 0 ) { t6 [ 3ULL ] = - t35 -> mU .
mX [ 1ULL ] ; } else { t6 [ 3ULL ] = 0.0 ; } if ( t35 -> mM . mX [ 4ULL ] !=
0 ) { t7 [ 2ULL ] = - t35 -> mU . mX [ 1ULL ] ; } else { t7 [ 2ULL ] = 0.0 ;
} t6 [ 0ULL ] = 1.0E-6 ; t6 [ 1ULL ] = 1.0E-6 ; t6 [ 2ULL ] = t35 -> mM . mX
[ 3ULL ] != 0 ? - t35 -> mU . mX [ 3ULL ] : 0.0 ; t7 [ 0ULL ] = 1.0E-6 ; t7 [
1ULL ] = 1.0E-6 ; t7 [ 3ULL ] = t35 -> mM . mX [ 5ULL ] != 0 ? - t35 -> mU .
mX [ 6ULL ] : 0.0 ; out -> mDXF . mX [ 0ULL ] = t0 / 1.0E+6 ; out -> mDXF .
mX [ 1ULL ] = t27 / 1.0E+6 ; out -> mDXF . mX [ 2ULL ] = t2 / 1.0E+6 ; for ( t12
= 0ULL ; t12 < 4ULL ; t12 ++ ) { out -> mDXF . mX [ t12 + 3ULL ] = t6 [ t12 ]
; } for ( t12 = 0ULL ; t12 < 4ULL ; t12 ++ ) { out -> mDXF . mX [ t12 + 7ULL
] = t7 [ t12 ] ; } out -> mDXF . mX [ 11ULL ] = - 1.0E-15 ; out -> mDXF . mX
[ 12ULL ] = - 1.0E-15 ; out -> mDXF . mX [ 13ULL ] = - 1.0 ; out -> mDXF . mX
[ 14ULL ] = 1.0E-15 ; out -> mDXF . mX [ 15ULL ] = 1.0 ; out -> mDXF . mX [
16ULL ] = 1.0E-15 ; out -> mDXF . mX [ 17ULL ] = 1.0 ; out -> mDXF . mX [
18ULL ] = 1.0E-15 ; out -> mDXF . mX [ 19ULL ] = 1.0 ; ( void ) sys ; ( void
) out ; return 0 ; }
