#include "ne_ds.h"
#include "SmartRegulering_tester_cb61fc2_49_ds_sys_struct.h"
#include "SmartRegulering_tester_cb61fc2_49_ds_obs_act.h"
#include "SmartRegulering_tester_cb61fc2_49_ds.h"
#include "SmartRegulering_tester_cb61fc2_49_ds_externals.h"
#include "SmartRegulering_tester_cb61fc2_49_ds_external_struct.h"
#include "ssc_ml_fun.h"
int32_T SmartRegulering_tester_cb61fc2_49_ds_obs_act ( const NeDynamicSystem
* sys , const NeDynamicSystemInput * t10 , NeDsMethodOutput * out ) { real_T
Jernbanenett_Current_Sensor10_I ; real_T Jernbanenett_Current_Sensor1_I ;
real_T Jernbanenett_Current_Sensor5_I ; real_T Jernbanenett_Current_Sensor6_I
; real_T Jernbanenett_Current_Sensor7_I ; real_T Jernbanenett_Inductor1_n_v ;
real_T Jernbanenett_Inductor2_n_v ; real_T t2 ;
Jernbanenett_Current_Sensor1_I = t10 -> mX . mX [ 6ULL ] + t10 -> mX . mX [
7ULL ] ; Jernbanenett_Current_Sensor10_I = - t10 -> mX . mX [ 0ULL ] + t10 ->
mX . mX [ 8ULL ] * - 1.0E-9 ; Jernbanenett_Current_Sensor5_I = t10 -> mX . mX
[ 11ULL ] * 1.0E-9 + t10 -> mX . mX [ 1ULL ] ; Jernbanenett_Current_Sensor6_I
= t10 -> mX . mX [ 12ULL ] * 1.0E-9 + t10 -> mX . mX [ 2ULL ] ;
Jernbanenett_Current_Sensor7_I = ( - t10 -> mX . mX [ 7ULL ] + t10 -> mX . mX
[ 11ULL ] * 1.0E-9 ) + t10 -> mX . mX [ 1ULL ] ; out -> mOBS_ACT . mX [ 51ULL
] = - t10 -> mX . mX [ 6ULL ] - t10 -> mX . mX [ 7ULL ] ;
Jernbanenett_Inductor1_n_v = - t10 -> mX . mX [ 12ULL ] + t10 -> mX . mX [
9ULL ] ; Jernbanenett_Inductor2_n_v = - t10 -> mX . mX [ 11ULL ] + t10 -> mU
. mX [ 7ULL ] ; t2 = - t10 -> mX . mX [ 8ULL ] + t10 -> mX . mX [ 9ULL ] ;
out -> mOBS_ACT . mX [ 135ULL ] = t10 -> mX . mX [ 13ULL ] ; out -> mOBS_ACT
. mX [ 142ULL ] = - t10 -> mX . mX [ 10ULL ] + t10 -> mX . mX [ 14ULL ] ; out
-> mOBS_ACT . mX [ 149ULL ] = - t10 -> mU . mX [ 7ULL ] + t10 -> mX . mX [
15ULL ] ; out -> mOBS_ACT . mX [ 0ULL ] = Jernbanenett_Current_Sensor1_I ;
out -> mOBS_ACT . mX [ 1ULL ] = Jernbanenett_Current_Sensor1_I ; out ->
mOBS_ACT . mX [ 2ULL ] = t10 -> mU . mX [ 4ULL ] ; out -> mOBS_ACT . mX [
3ULL ] = t10 -> mU . mX [ 4ULL ] ; out -> mOBS_ACT . mX [ 4ULL ] =
Jernbanenett_Current_Sensor10_I ; out -> mOBS_ACT . mX [ 5ULL ] =
Jernbanenett_Current_Sensor10_I ; out -> mOBS_ACT . mX [ 6ULL ] = t10 -> mX .
mX [ 9ULL ] ; out -> mOBS_ACT . mX [ 7ULL ] = t10 -> mX . mX [ 9ULL ] ; out
-> mOBS_ACT . mX [ 8ULL ] = Jernbanenett_Current_Sensor10_I ; out -> mOBS_ACT
. mX [ 9ULL ] = Jernbanenett_Current_Sensor1_I ; out -> mOBS_ACT . mX [ 10ULL
] = t10 -> mX . mX [ 6ULL ] ; out -> mOBS_ACT . mX [ 11ULL ] = t10 -> mX . mX
[ 6ULL ] ; out -> mOBS_ACT . mX [ 12ULL ] = t10 -> mX . mX [ 10ULL ] ; out ->
mOBS_ACT . mX [ 13ULL ] = t10 -> mX . mX [ 10ULL ] ; out -> mOBS_ACT . mX [
14ULL ] = t10 -> mX . mX [ 6ULL ] ; out -> mOBS_ACT . mX [ 15ULL ] =
Jernbanenett_Current_Sensor1_I ; out -> mOBS_ACT . mX [ 16ULL ] =
Jernbanenett_Current_Sensor1_I ; out -> mOBS_ACT . mX [ 17ULL ] = t10 -> mX .
mX [ 10ULL ] ; out -> mOBS_ACT . mX [ 18ULL ] = t10 -> mX . mX [ 10ULL ] ;
out -> mOBS_ACT . mX [ 19ULL ] = Jernbanenett_Current_Sensor1_I ; out ->
mOBS_ACT . mX [ 20ULL ] = t10 -> mX . mX [ 7ULL ] ; out -> mOBS_ACT . mX [
21ULL ] = t10 -> mX . mX [ 7ULL ] ; out -> mOBS_ACT . mX [ 22ULL ] = t10 ->
mX . mX [ 10ULL ] ; out -> mOBS_ACT . mX [ 23ULL ] = t10 -> mX . mX [ 10ULL ]
; out -> mOBS_ACT . mX [ 24ULL ] = t10 -> mX . mX [ 7ULL ] ; out -> mOBS_ACT
. mX [ 25ULL ] = Jernbanenett_Current_Sensor5_I ; out -> mOBS_ACT . mX [
26ULL ] = Jernbanenett_Current_Sensor5_I ; out -> mOBS_ACT . mX [ 27ULL ] =
t10 -> mX . mX [ 9ULL ] ; out -> mOBS_ACT . mX [ 28ULL ] = t10 -> mX . mX [
9ULL ] ; out -> mOBS_ACT . mX [ 29ULL ] = Jernbanenett_Current_Sensor5_I ;
out -> mOBS_ACT . mX [ 30ULL ] = Jernbanenett_Current_Sensor6_I ; out ->
mOBS_ACT . mX [ 31ULL ] = Jernbanenett_Current_Sensor6_I ; out -> mOBS_ACT .
mX [ 32ULL ] = t10 -> mX . mX [ 9ULL ] ; out -> mOBS_ACT . mX [ 33ULL ] = t10
-> mX . mX [ 9ULL ] ; out -> mOBS_ACT . mX [ 34ULL ] =
Jernbanenett_Current_Sensor6_I ; out -> mOBS_ACT . mX [ 35ULL ] =
Jernbanenett_Current_Sensor7_I ; out -> mOBS_ACT . mX [ 36ULL ] =
Jernbanenett_Current_Sensor7_I ; out -> mOBS_ACT . mX [ 37ULL ] = t10 -> mU .
mX [ 7ULL ] ; out -> mOBS_ACT . mX [ 38ULL ] = t10 -> mU . mX [ 7ULL ] ; out
-> mOBS_ACT . mX [ 39ULL ] = Jernbanenett_Current_Sensor7_I ; out -> mOBS_ACT
. mX [ 40ULL ] = - Jernbanenett_Current_Sensor6_I ; out -> mOBS_ACT . mX [
41ULL ] = - Jernbanenett_Current_Sensor6_I ; out -> mOBS_ACT . mX [ 42ULL ] =
t10 -> mU . mX [ 8ULL ] ; out -> mOBS_ACT . mX [ 43ULL ] = t10 -> mU . mX [
8ULL ] ; out -> mOBS_ACT . mX [ 44ULL ] = - Jernbanenett_Current_Sensor6_I ;
out -> mOBS_ACT . mX [ 45ULL ] = 0.0 ; out -> mOBS_ACT . mX [ 46ULL ] = 0.0 ;
out -> mOBS_ACT . mX [ 47ULL ] = t10 -> mU . mX [ 4ULL ] ; out -> mOBS_ACT .
mX [ 48ULL ] = t10 -> mU . mX [ 4ULL ] ; out -> mOBS_ACT . mX [ 49ULL ] = 0.0
; out -> mOBS_ACT . mX [ 50ULL ] = 0.0 ; out -> mOBS_ACT . mX [ 52ULL ] = 0.0
; out -> mOBS_ACT . mX [ 53ULL ] = t10 -> mU . mX [ 4ULL ] ; out -> mOBS_ACT
. mX [ 54ULL ] = t10 -> mU . mX [ 4ULL ] ; out -> mOBS_ACT . mX [ 55ULL ] =
t10 -> mU . mX [ 4ULL ] ; out -> mOBS_ACT . mX [ 56ULL ] = -
Jernbanenett_Current_Sensor7_I ; out -> mOBS_ACT . mX [ 57ULL ] = 0.0 ; out
-> mOBS_ACT . mX [ 58ULL ] = t10 -> mU . mX [ 7ULL ] ; out -> mOBS_ACT . mX [
59ULL ] = t10 -> mU . mX [ 7ULL ] ; out -> mOBS_ACT . mX [ 60ULL ] = t10 ->
mU . mX [ 7ULL ] ; out -> mOBS_ACT . mX [ 61ULL ] =
Jernbanenett_Current_Sensor6_I ; out -> mOBS_ACT . mX [ 62ULL ] = 0.0 ; out
-> mOBS_ACT . mX [ 63ULL ] = t10 -> mU . mX [ 8ULL ] ; out -> mOBS_ACT . mX [
64ULL ] = t10 -> mU . mX [ 8ULL ] ; out -> mOBS_ACT . mX [ 65ULL ] = t10 ->
mU . mX [ 8ULL ] ; out -> mOBS_ACT . mX [ 66ULL ] = 0.0 ; out -> mOBS_ACT .
mX [ 67ULL ] = 0.0 ; out -> mOBS_ACT . mX [ 68ULL ] =
Jernbanenett_Inductor1_n_v ; out -> mOBS_ACT . mX [ 69ULL ] = t10 -> mX . mX
[ 9ULL ] ; out -> mOBS_ACT . mX [ 70ULL ] = Jernbanenett_Current_Sensor6_I ;
out -> mOBS_ACT . mX [ 71ULL ] = t10 -> mX . mX [ 2ULL ] ; out -> mOBS_ACT .
mX [ 72ULL ] = t10 -> mX . mX [ 12ULL ] * t10 -> mX . mX [ 12ULL ] *
1.0000000000000002E-12 * 1000.0 ; out -> mOBS_ACT . mX [ 73ULL ] = t10 -> mX
. mX [ 12ULL ] ; out -> mOBS_ACT . mX [ 74ULL ] = 0.0 ; out -> mOBS_ACT . mX
[ 75ULL ] = 0.0 ; out -> mOBS_ACT . mX [ 76ULL ] = Jernbanenett_Inductor2_n_v
; out -> mOBS_ACT . mX [ 77ULL ] = t10 -> mU . mX [ 7ULL ] ; out -> mOBS_ACT
. mX [ 78ULL ] = Jernbanenett_Current_Sensor5_I ; out -> mOBS_ACT . mX [
79ULL ] = t10 -> mX . mX [ 1ULL ] ; out -> mOBS_ACT . mX [ 80ULL ] = t10 ->
mX . mX [ 11ULL ] * t10 -> mX . mX [ 11ULL ] * 1.0000000000000002E-12 *
1000.0 ; out -> mOBS_ACT . mX [ 81ULL ] = t10 -> mX . mX [ 11ULL ] ; out ->
mOBS_ACT . mX [ 82ULL ] = 0.0 ; out -> mOBS_ACT . mX [ 83ULL ] = 0.0 ; out ->
mOBS_ACT . mX [ 84ULL ] = t2 ; out -> mOBS_ACT . mX [ 85ULL ] = t10 -> mX .
mX [ 9ULL ] ; out -> mOBS_ACT . mX [ 86ULL ] = -
Jernbanenett_Current_Sensor10_I ; out -> mOBS_ACT . mX [ 87ULL ] = t10 -> mX
. mX [ 0ULL ] ; out -> mOBS_ACT . mX [ 88ULL ] = t10 -> mX . mX [ 8ULL ] *
t10 -> mX . mX [ 8ULL ] * 1.0000000000000002E-12 * 1000.0 ; out -> mOBS_ACT .
mX [ 89ULL ] = t10 -> mX . mX [ 8ULL ] ; out -> mOBS_ACT . mX [ 90ULL ] =
Jernbanenett_Current_Sensor6_I ; out -> mOBS_ACT . mX [ 91ULL ] = t10 -> mU .
mX [ 8ULL ] ; out -> mOBS_ACT . mX [ 92ULL ] = Jernbanenett_Inductor1_n_v ;
out -> mOBS_ACT . mX [ 93ULL ] = Jernbanenett_Current_Sensor6_I *
7.1999999999999993 ; out -> mOBS_ACT . mX [ 94ULL ] =
Jernbanenett_Current_Sensor5_I ; out -> mOBS_ACT . mX [ 95ULL ] = t10 -> mX .
mX [ 9ULL ] ; out -> mOBS_ACT . mX [ 96ULL ] = Jernbanenett_Inductor2_n_v ;
out -> mOBS_ACT . mX [ 97ULL ] = Jernbanenett_Current_Sensor5_I *
7.1999999999999993 ; out -> mOBS_ACT . mX [ 98ULL ] = -
Jernbanenett_Current_Sensor10_I ; out -> mOBS_ACT . mX [ 99ULL ] = 0.0 ; out
-> mOBS_ACT . mX [ 100ULL ] = t2 ; out -> mOBS_ACT . mX [ 101ULL ] =
Jernbanenett_Current_Sensor10_I * - 60.2 ; out -> mOBS_ACT . mX [ 102ULL ] =
t10 -> mU . mX [ 0ULL ] ; out -> mOBS_ACT . mX [ 103ULL ] = t10 -> mU . mX [
1ULL ] ; out -> mOBS_ACT . mX [ 104ULL ] = t10 -> mU . mX [ 2ULL ] ; out ->
mOBS_ACT . mX [ 105ULL ] = t10 -> mU . mX [ 3ULL ] ; out -> mOBS_ACT . mX [
106ULL ] = t10 -> mU . mX [ 4ULL ] ; out -> mOBS_ACT . mX [ 107ULL ] = t10 ->
mU . mX [ 5ULL ] ; out -> mOBS_ACT . mX [ 108ULL ] = t10 -> mU . mX [ 6ULL ]
; out -> mOBS_ACT . mX [ 109ULL ] = t10 -> mU . mX [ 7ULL ] ; out -> mOBS_ACT
. mX [ 110ULL ] = t10 -> mU . mX [ 8ULL ] ; out -> mOBS_ACT . mX [ 111ULL ] =
t10 -> mU . mX [ 2ULL ] ; out -> mOBS_ACT . mX [ 112ULL ] = t10 -> mX . mX [
6ULL ] ; out -> mOBS_ACT . mX [ 113ULL ] = t10 -> mX . mX [ 13ULL ] ; out ->
mOBS_ACT . mX [ 114ULL ] = t10 -> mX . mX [ 10ULL ] ; out -> mOBS_ACT . mX [
115ULL ] = t10 -> mX . mX [ 3ULL ] ; out -> mOBS_ACT . mX [ 116ULL ] = ( t10
-> mX . mX [ 10ULL ] - t10 -> mX . mX [ 13ULL ] ) * ( t10 -> mX . mX [ 10ULL
] - t10 -> mX . mX [ 13ULL ] ) * 1.0000000000000002E-12 * 1000.0 ; out ->
mOBS_ACT . mX [ 117ULL ] = t10 -> mU . mX [ 0ULL ] ; out -> mOBS_ACT . mX [
118ULL ] = Jernbanenett_Current_Sensor1_I ; out -> mOBS_ACT . mX [ 119ULL ] =
t10 -> mX . mX [ 14ULL ] ; out -> mOBS_ACT . mX [ 120ULL ] = t10 -> mU . mX [
4ULL ] ; out -> mOBS_ACT . mX [ 121ULL ] = t10 -> mX . mX [ 4ULL ] ; out ->
mOBS_ACT . mX [ 122ULL ] = ( t10 -> mU . mX [ 4ULL ] - t10 -> mX . mX [ 14ULL
] ) * ( t10 -> mU . mX [ 4ULL ] - t10 -> mX . mX [ 14ULL ] ) *
1.0000000000000002E-12 * 1000.0 ; out -> mOBS_ACT . mX [ 123ULL ] = t10 -> mU
. mX [ 5ULL ] ; out -> mOBS_ACT . mX [ 124ULL ] = t10 -> mX . mX [ 7ULL ] ;
out -> mOBS_ACT . mX [ 125ULL ] = t10 -> mX . mX [ 15ULL ] ; out -> mOBS_ACT
. mX [ 126ULL ] = t10 -> mX . mX [ 10ULL ] ; out -> mOBS_ACT . mX [ 127ULL ]
= t10 -> mX . mX [ 5ULL ] ; out -> mOBS_ACT . mX [ 128ULL ] = ( t10 -> mX .
mX [ 10ULL ] - t10 -> mX . mX [ 15ULL ] ) * ( t10 -> mX . mX [ 10ULL ] - t10
-> mX . mX [ 15ULL ] ) * 1.0000000000000002E-12 * 1000.0 ; out -> mOBS_ACT .
mX [ 129ULL ] = 0.0 ; out -> mOBS_ACT . mX [ 130ULL ] = t10 -> mU . mX [ 3ULL
] ; out -> mOBS_ACT . mX [ 131ULL ] = 0.0 ; out -> mOBS_ACT . mX [ 132ULL ] =
t10 -> mX . mX [ 6ULL ] ; out -> mOBS_ACT . mX [ 133ULL ] = 0.0 ; out ->
mOBS_ACT . mX [ 134ULL ] = t10 -> mX . mX [ 13ULL ] ; out -> mOBS_ACT . mX [
136ULL ] = 0.0 ; out -> mOBS_ACT . mX [ 137ULL ] = t10 -> mU . mX [ 1ULL ] ;
out -> mOBS_ACT . mX [ 138ULL ] = 0.0 ; out -> mOBS_ACT . mX [ 139ULL ] =
Jernbanenett_Current_Sensor1_I ; out -> mOBS_ACT . mX [ 140ULL ] = t10 -> mX
. mX [ 10ULL ] ; out -> mOBS_ACT . mX [ 141ULL ] = t10 -> mX . mX [ 14ULL ] ;
out -> mOBS_ACT . mX [ 143ULL ] = 0.0 ; out -> mOBS_ACT . mX [ 144ULL ] = t10
-> mU . mX [ 6ULL ] ; out -> mOBS_ACT . mX [ 145ULL ] = 0.0 ; out -> mOBS_ACT
. mX [ 146ULL ] = t10 -> mX . mX [ 7ULL ] ; out -> mOBS_ACT . mX [ 147ULL ] =
t10 -> mU . mX [ 7ULL ] ; out -> mOBS_ACT . mX [ 148ULL ] = t10 -> mX . mX [
15ULL ] ; out -> mOBS_ACT . mX [ 150ULL ] = t10 -> mU . mX [ 4ULL ] ; out ->
mOBS_ACT . mX [ 151ULL ] = 0.0 ; out -> mOBS_ACT . mX [ 152ULL ] = t10 -> mU
. mX [ 4ULL ] ; out -> mOBS_ACT . mX [ 153ULL ] = t10 -> mU . mX [ 4ULL ] ;
out -> mOBS_ACT . mX [ 154ULL ] = t10 -> mU . mX [ 7ULL ] ; out -> mOBS_ACT .
mX [ 155ULL ] = 0.0 ; out -> mOBS_ACT . mX [ 156ULL ] = t10 -> mU . mX [ 7ULL
] ; out -> mOBS_ACT . mX [ 157ULL ] = t10 -> mU . mX [ 7ULL ] ; out ->
mOBS_ACT . mX [ 158ULL ] = t10 -> mU . mX [ 8ULL ] ; out -> mOBS_ACT . mX [
159ULL ] = 0.0 ; out -> mOBS_ACT . mX [ 160ULL ] = t10 -> mU . mX [ 8ULL ] ;
out -> mOBS_ACT . mX [ 161ULL ] = t10 -> mU . mX [ 8ULL ] ; ( void ) sys ; ( void ) out ; return 0 ; }
