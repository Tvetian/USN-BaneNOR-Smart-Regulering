#ifndef SmartRegulering_tester_capi_h_
#define SmartRegulering_tester_capi_h_
#include "SmartRegulering_tester.h"
extern void SmartRegulering_tester_InitializeDataMapInfo ( void ) ;
#endif
