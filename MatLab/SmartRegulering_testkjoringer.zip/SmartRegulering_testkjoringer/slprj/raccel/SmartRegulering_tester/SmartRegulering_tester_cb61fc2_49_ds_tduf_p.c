#include "ne_ds.h"
#include "SmartRegulering_tester_cb61fc2_49_ds_sys_struct.h"
#include "SmartRegulering_tester_cb61fc2_49_ds_tduf_p.h"
#include "SmartRegulering_tester_cb61fc2_49_ds.h"
#include "SmartRegulering_tester_cb61fc2_49_ds_externals.h"
#include "SmartRegulering_tester_cb61fc2_49_ds_external_struct.h"
#include "ssc_ml_fun.h"
int32_T SmartRegulering_tester_cb61fc2_49_ds_tduf_p ( const NeDynamicSystem *
sys , const NeDynamicSystemInput * t1 , NeDsMethodOutput * out ) { static
int32_T _cg_const_2 [ 11 ] = { 10 , 13 , 9 , 12 , 4 , 10 , 11 , 14 , 7 , 14 ,
6 } ; static int32_T _cg_const_1 [ 10 ] = { 0 , 1 , 2 , 3 , 4 , 6 , 7 , 8 ,
10 , 11 } ; ( void ) t1 ; out -> mTDUF_P . mNumCol = 9ULL ; out -> mTDUF_P .
mNumRow = 16ULL ; out -> mTDUF_P . mJc [ 0 ] = _cg_const_1 [ 0 ] ; out ->
mTDUF_P . mJc [ 1 ] = _cg_const_1 [ 1 ] ; out -> mTDUF_P . mJc [ 2 ] =
_cg_const_1 [ 2 ] ; out -> mTDUF_P . mJc [ 3 ] = _cg_const_1 [ 3 ] ; out ->
mTDUF_P . mJc [ 4 ] = _cg_const_1 [ 4 ] ; out -> mTDUF_P . mJc [ 5 ] =
_cg_const_1 [ 5 ] ; out -> mTDUF_P . mJc [ 6 ] = _cg_const_1 [ 6 ] ; out ->
mTDUF_P . mJc [ 7 ] = _cg_const_1 [ 7 ] ; out -> mTDUF_P . mJc [ 8 ] =
_cg_const_1 [ 8 ] ; out -> mTDUF_P . mJc [ 9 ] = _cg_const_1 [ 9 ] ; out ->
mTDUF_P . mIr [ 0 ] = _cg_const_2 [ 0 ] ; out -> mTDUF_P . mIr [ 1 ] =
_cg_const_2 [ 1 ] ; out -> mTDUF_P . mIr [ 2 ] = _cg_const_2 [ 2 ] ; out ->
mTDUF_P . mIr [ 3 ] = _cg_const_2 [ 3 ] ; out -> mTDUF_P . mIr [ 4 ] =
_cg_const_2 [ 4 ] ; out -> mTDUF_P . mIr [ 5 ] = _cg_const_2 [ 5 ] ; out ->
mTDUF_P . mIr [ 6 ] = _cg_const_2 [ 6 ] ; out -> mTDUF_P . mIr [ 7 ] =
_cg_const_2 [ 7 ] ; out -> mTDUF_P . mIr [ 8 ] = _cg_const_2 [ 8 ] ; out ->
mTDUF_P . mIr [ 9 ] = _cg_const_2 [ 9 ] ; out -> mTDUF_P . mIr [ 10 ] =
_cg_const_2 [ 10 ] ; ( void ) sys ; ( void ) out ; return 0 ; }
