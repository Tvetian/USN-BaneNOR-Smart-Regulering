#ifndef __SmartRegulering_tester_cb61fc2_1_gateway_h__
#define __SmartRegulering_tester_cb61fc2_1_gateway_h__
#ifdef __cplusplus
extern "C" {
#endif
extern void SmartRegulering_tester_cb61fc2_1_gateway ( void ) ;
#ifdef __cplusplus
}
#endif
#endif
