%Init felles parameter

sample_tid = 0.001; %[s]
simulering_tid = 10000; %[s]






